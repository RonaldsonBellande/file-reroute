def test_import():
    from file_reroute.reroute import reroute
